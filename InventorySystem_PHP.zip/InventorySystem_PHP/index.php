<html>
        <title>StockFlow - Inventory Management</title>
        <style>
            *,*::before,*::after{box-sizing:border-box}body,h1,h2,h3,h4,p,figure,blockquote,dl,dd{margin:0}ul[role="list"],ol[role="list"]{list-style:none}html:focus-within{scroll-behavior:smooth}body{min-height:100vh;text-rendering:optimizeSpeed;line-height:1.5}a:not([class]){text-decoration-skip-ink:auto}img,picture{max-width:100%;display:block}input,button,textarea,select{font:inherit}@media(prefers-reduced-motion:reduce){html:focus-within{scroll-behavior:auto}*,*::before,*::after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important;scroll-behavior:auto !important}}
            body {
                font-family: Arial, sans-serif;
            } 
            div.header{
                width: 100%;
                height: 60px;
                background: #0de9c1;
                padding: 20px;
            }
            div.header a{
                font-size: 21px;
                padding-right: 100px;
                margin-left: 1050px;
                color: #000000;
                border: 2px solid #0de9c1;
                padding: 10px 15px;
                text-decoration: none;
                border-radius: 6px;
            }
            div.header a:hover{
                transition: 0.5s all;
                color: white;
                background: black;
            }
            div.banner{
                background: url(1.jpg) no-repeat center center fixed;
                background-size: cover;
                padding-top: 100px;
                padding-bottom: 100px;
                height: 80vh;
            }
            div.homepageContainer{
                width: 100%;
                max-width: 1000px;
                height: 50vh;
                margin: 0 auto;
            }
            div.bannerHeader{
                padding-top: 50px;
            }
            div.bannerHeader h1{
                font-size: 60px;
                color: #0de9c1;
                line-height: 100%;
                padding-top: 60px;
            }
            div.bannerHeader p{
                font-size: 40px;
                color: #0de9c1;
                text-transform: uppercase;
                line-height: 100%;
            }
            .bannerTagline {
                margin-top: 20px;
                font-size: 25px;
                color: #0de9c1;
            }
            div.bannerIcons{
                margin-top: 50px;
            }
            div.bannerIcons a{
                font-size: 23px;
                margin-left: 40px;
                padding: 12px 16px;
                background-color: rgba(0, 0, 0, 0.5);
                color: #868485;
                border-radius: 50%;
                width: 50px;
                height: 50px;
                display: inline-block;
                text-align: center;
                line-height: 26px;
            }
            div.bannerIcons a:first-child{
                margin-left: 0px;
            }
            div.bannerIcons a:hover{
                color: #fff;
                background: #0de9c1;
                font-size: 25px;
                transition: .5s all;
            }
            div.homepageFeatures{
                display: flex;
                flex-direction: row;
                padding: 50px 0px;
            }
            div.homepageFeature{
                padding: 10px 20px;
                text-align: center;
            }
            div.homepageFeature:hover{
                border-top: 2px solid #0de9c1;
                border-bottom: 2px solid #0de9c1;
                transition: 0.5s all;
            }
            div.homepageFeature span.featureIcons{
                height: 80px;
                width: 80px;
                display: inline-block;
                font-size: 50px;
                background: #0de9c1;
                color: #fff;
                padding-left: 18px;
                padding-top: 16px;
                padding-right: 15px;
                border-radius: 50%;
                margin-bottom: 20px;
            }
            div.homepageFeature h3.featureTitle{
                margin-bottom: 20px;
                font-size: 15px;
            }
            div.homepageFeature p.featureDescription{
                color: black;
                font-size: 20px;
            }
            div.homepageNotified{
                background: #0de9c1;
                padding: 80px 0px;
                text-align: center;
                padding-left: 550px;
            }
            div.homepageNotifiedContainer{
                display: flex;
                flex-direction: row;
            }
            div.homepageNotifiedContainer>div{
                width: 50%;
            }
            div.emailForm h3{
                font-size: 30px;
            }
            div.emailForm{
                width: 40%;
            }
            div.homepageNotified h3{
                margin-bottom: 20px;
            }
            div.homepageNotified p{
                color: rgb(0, 0, 0);
                line-height: 200%;
                margin-bottom: 30px;
                padding-left: 20px;
            }
            div.formContainer{
                width: 100%;
                position: relative;
            }
            div.formContainer input{
                width: 100%;
                margin-right: 60px;
                padding: 15px 10px;
                border-radius: 15px;
                border: none;

            }
            div.formContainer button{
                position: absolute;
                right: 0;
                top: 0;
                height: 100%;
                font-size: 18px;
                padding: 0px 20px;
                background: #000000;
                border: none;
                border-radius: 15px;
                color: rgb(255, 255, 255);
                border-top-right-radius: 15px;
                border-bottom-right-radius: 15px;
            }
            div.formContainer input:focus{
                outline: none;
            }
            div.socials{
                text-align: center;
                padding: 60px 0px 30px 0px;
            }
            h3.socialHeader{
                font-size: 30px;
            }
            p.socialText{
                margin-top: 20px;
                margin-bottom: 25px;
                color: #868485;
                font-size: 20px;
            }
            div.socialIconsContainer a{
                font-size: 23px;
                height: 50px;
                width: 50px;
                display: inline-block;
                padding-top: 15px;
                background: #000000;
                border-radius: 50px;
                color: #fff;
                margin-left: 20px;
            }
            div.socialIconsContainer a:hover{
                background: #0de9c1;
                transition: 0.5s all;
            }
            div.footer{
                background: #e3e3e3;
                padding-top: 50px;
                padding-bottom: 50px;
                text-align: center;
            }
            div.footer a{
                color: #868484;
                margin-left: 30px;
                text-decoration: none;
            }
            div.homepageContainers{
                height: 30vh;
            }
            div.homepageContainerss{
                height: 5vh;
            }
            div.homepageContaine{
                height: 30vh;
            }
            div.footer a:hover{
                font-weight: bold;
                color: #0de9c1;
                transition: 0.8s all;
            }
        </style>
        <script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
    </head>
    <body>
        <div class="header">
            <div class="homepageContainer">
                <a href="login.php">Login</a>
            </div>
        </div>
        <div class="banner">
            <div class="homepageContainer">
                <div class="bannerHeader">
                    <h1>StockFlow</h1>
                    <p>Inventory Management</p>
                </div>
                <p class="bannerTagline">
                    Track Your goods through your entire supply chain from Purchasing to Production to end sales</p>
                <div class="bannerIcons">
                    <a href="#"><i class="fa fa-apple"></i></a>
                    <a href="#"><i class="fa fa-android"></i></a>
                    <a href="#"><i class="fa fa-windows"></i></a>
                </div>
            </div>
        </div>
        <div class="homepageContainer">
            <div class="homepageFeatures">
                <div class="homepageFeature">
                    <span class="featureIcons"><i class="fa fa-gear"></i></span>
                    <h3 class="featureTitle">Streamlined Operations</h3>
                    <p class="featureDescription">Simplify your workflow by managing inventory in real-time, reducing manual errors, and improving efficiency across your supply chain.</p>
                </div>
                <div class="homepageFeature">
                    <span class="featureIcons"><i class="fa fa-star"></i></span>
                    <h3 class="featureTitle">Real-Time Analytics</h3>
                    <p class="featureDescription">Gain insights with real-time inventory tracking and actionable analytics to make smarter decisions for your business.</p>
                </div>
                <div class="homepageFeature">
                    <span class="featureIcons"><i class="fa fa-globe"></i></span>
                    <h3 class="featureTitle">Seamless Integration</h3>
                    <p class="featureDescription">Easily integrate with your existing systems, from e-commerce platforms to accounting software, for a unified business experience.</p>
                </div>
            </div>
        </div>
        <div class="homepageNotified">
            <div class="homepageContaine">
                <div class="homepageNotifiedContainer">
                    <div class="emailform">
                        <h3>Get Notified Of Any Updates!</h3>
                        <p>Enter Your Email To Notify Soon </p>
                        <form action="#">
                            <div class="formContainer">
                                <input type="email" placeholder="Email Address" required />
                                <button type="submit">Notify</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="socials">
            <div class="homepageContainers">
                <h3 class="socialHeader">Say Hi & Get In Touch</h3>
                <p class="socialText">Message Us For Help Or Get Service</p>
                <div class="socialIconsContainer">
                    <a href=""><i class="fa fa-twitter"></i></a>
                    <a href=""><i class="fa fa-facebook"></i></a>
                    <a href=""><i class="fa fa-instagram"></i></a>
                    <a href=""><i class="fa fa-youtube"></i></a>
                    <a href=""><i class="fa fa-linkedin"></i></a>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="homepageContainerss">
                <a href="">Contact</a>
                <a href="">Download</a>
                <a href="">E-mail</a>
                <a href="">Support</a>
                <a href="">Privacy Policy</a>
            </div>
        </div>
    </body>
</html>
